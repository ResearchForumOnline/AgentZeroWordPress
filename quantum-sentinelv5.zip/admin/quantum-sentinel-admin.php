<?php
// admin/quantum-sentinel-admin.php

/**
 * Adds the top-level menu page for Quantum Sentinel settings.
 */
add_action('admin_menu', function () {
    add_menu_page(
        'Quantum Sentinel',             // Page title
        'Quantum Sentinel',             // Menu title
        'manage_options',               // Capability required to access the menu
        'quantum-sentinel-settings',    // Menu slug
        'quantum_sentinel_settings_html', // Callback function to render the page content
        'dashicons-superhero-alt',      // Icon URL or Dashicons class (more fitting for Sentinel)
        80                              // Position in the menu
    );
});

/**
 * Renders the HTML content for the Quantum Sentinel settings page.
 * This includes forms for API settings only.
 */
function quantum_sentinel_settings_html() {
    // Retrieve hardcoded agent identity for display purposes (not editable here)
    $master_data = quantum_sentinel_get_master_knowledge_base();
    $agent_name = esc_html($master_data['identity']['name']);
    ?>

    <div class="wrap">
        <h1><?php echo $agent_name; ?> Settings</h1>
        <p>Configure the API settings for your **Quantum Sentinel** AI. Agent identity and core knowledge base are deeply integrated and not user-editable, ensuring consistent performance and integrity.</p>
        <form method="post" action="options.php">
            <?php
                // Output necessary hidden fields for settings API
                settings_fields('quantum_sentinel_settings_group');
                // Output settings sections and fields
                do_settings_sections('quantum-sentinel-settings');
                // Output save changes button
                submit_button();
            ?>
        </form>

        <hr>
        <h2>Quantum Sentinel Core Data</h2>
        <p>
            **Agent Name:** <?php echo $agent_name; ?><br/>
            **Personality:** <?php echo esc_html($master_data['identity']['personality']); ?><br/>
            **Mission:** <?php echo esc_html($master_data['identity']['mission']); ?><br/>
            **Welcome Message:** <?php echo esc_html($master_data['identity']['welcome']); ?><br/>
        </p>
        <p>
            The core knowledge base for Quantum Sentinel is deeply integrated and comprises over 2MB of specialized data. It is not directly editable via this interface, ensuring the integrity and advanced capabilities of the AI.
        </p>

        <hr>
        <p style="opacity:0.7; font-size:0.9em;">Plugin by <a href='https://researchforum.online' target='_blank'>researchforum.online</a>,
        <a href='https://talktoai.org' target='_blank'>talktoai.org</a>,
        <a href='https://x.com/talktoai' target='_blank'>x.com/talktoai</a></p>
    </div>
    <?php
}

/**
 * Registers all plugin settings with the WordPress Settings API.
 * Includes sanitization callbacks for security and data integrity.
 */
add_action('admin_init', function () {
    // --- Sanitization Callbacks ---
    // Helper function to sanitize API provider
    function quantum_sentinel_sanitize_api_provider($provider) {
        $allowed_providers = ['openai', 'groq', 'google', 'xai'];
        if (in_array($provider, $allowed_providers)) {
            return $provider;
        }
        return 'google'; // Default to google if invalid
    }

    // Helper function to sanitize AI model
    function quantum_sentinel_sanitize_ai_model($model) {
        $provider = get_option('quantum_sentinel_api_provider', 'google');
        $allowed_models = [
            'openai' => ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'],
            'groq' => ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'],
            'google' => ['gemini-2.0-flash', 'gemini-2.0-pro'],
            'xai' => ['grok-1'] // Placeholder, adjust as needed
        ];
        if (isset($allowed_models[$provider]) && in_array($model, $allowed_models[$provider])) {
            return $model;
        }
        // Fallback to a default for the current provider if the selected model is invalid
        return $allowed_models[$provider][0] ?? 'gemini-2.0-flash';
    }

    // Register settings fields with sanitization callbacks
    register_setting('quantum_sentinel_settings_group', 'quantum_sentinel_api_key', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('quantum_sentinel_settings_group', 'quantum_sentinel_api_provider', ['sanitize_callback' => 'quantum_sentinel_sanitize_api_provider']);
    register_setting('quantum_sentinel_settings_group', 'quantum_sentinel_model', ['sanitize_callback' => 'quantum_sentinel_sanitize_ai_model']);

    // Add a settings section
    add_settings_section(
        'quantum_sentinel_main_section', // ID of the section
        'API Settings',                  // Title of the section
        null,                            // Callback function for section description (none needed here)
        'quantum-sentinel-settings'      // Page slug where this section will appear
    );

    // Add individual settings fields to the section
    add_settings_field(
        'quantum_sentinel_api_provider',
        'AI API Provider',
        function () {
            $val = get_option('quantum_sentinel_api_provider', 'google');
            echo '<select name="quantum_sentinel_api_provider" id="quantum_sentinel_api_provider">
                    <option value="openai" ' . selected($val, 'openai', false) . '>OpenAI</option>
                    <option value="groq" ' . selected($val, 'groq', false) . '>Groq</option>
                    <option value="google" ' . selected($val, 'google', false) . '>Google Gemini</option>
                    <option value="xai" ' . selected($val, 'xai', false) . '>xAI Grok</option>
                  </select>';
            echo '<p class="description">Choose the AI service to power your Quantum Sentinel. This selection will affect available models.</p>';
        },
        'quantum-sentinel-settings',
        'quantum_sentinel_main_section'
    );

    add_settings_field(
        'quantum_sentinel_model',
        'AI Model Name',
        function () {
            $provider = get_option('quantum_sentinel_api_provider', 'google');
            $selected_model = get_option('quantum_sentinel_model'); // Get the currently saved model
            $models = [
                'openai' => ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'],
                'groq' => ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'],
                'google' => ['gemini-2.0-flash', 'gemini-2.0-pro'],
                'xai' => ['grok-1']
            ];

            // Ensure the selected model is valid for the current provider, fallback if not
            if (!in_array($selected_model, $models[$provider] ?? []) && isset($models[$provider][0])) {
                $selected_model = $models[$provider][0];
            } elseif (!isset($models[$provider][0])) {
                $selected_model = 'N/A'; // No models available for this provider
            }

            echo '<select name="quantum_sentinel_model" id="quantum_sentinel_model_select">';
            if (isset($models[$provider])) {
                foreach ($models[$provider] as $m) {
                    echo '<option value="' . esc_attr($m) . '" ' . selected($selected_model, $m, false) . '>' . esc_html($m) . '</option>';
                }
            } else {
                echo '<option value="">No models available</option>';
            }
            echo '</select>';
            echo '<p class="description">Select the specific AI model to use. Options update based on provider.</p>';
            ?>
            <script>
            jQuery(document).ready(function($) {
                // Function to update models based on selected provider
                function updateModels() {
                    var provider = $('#quantum_sentinel_api_provider').val();
                    var models = {
                        'openai': ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'],
                        'groq': ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'],
                        'google': ['gemini-2.0-flash', 'gemini-2.0-pro'],
                        'xai': ['grok-1']
                    };
                    var $modelSelect = $('#quantum_sentinel_model_select');
                    $modelSelect.empty(); // Clear current options

                    if (models[provider]) {
                        $.each(models[provider], function(index, model) {
                            $modelSelect.append($('<option>', {
                                value: model,
                                text: model
                            }));
                        });
                        // Attempt to re-select the previously chosen model if it exists in the new list
                        var currentModel = '<?php echo esc_js(get_option('quantum_sentinel_model')); ?>';
                        if (models[provider].includes(currentModel)) {
                             $modelSelect.val(currentModel);
                        } else if (models[provider].length > 0) {
                            // Otherwise, select the first model in the new list
                            $modelSelect.val(models[provider][0]);
                        }
                    } else {
                        $modelSelect.append($('<option>', {
                            value: '',
                            text: 'No models available'
                        }));
                    }
                }

                // Initial call to set models based on current provider on page load
                updateModels();

                // Bind change event to API provider select
                $('#quantum_sentinel_api_provider').change(function() {
                    updateModels();
                });
            });
            </script>
            <?php
        },
        'quantum-sentinel-settings',
        'quantum_sentinel_main_section'
    );

    add_settings_field(
        'quantum_sentinel_api_key',
        'API Key',
        function () {
            echo '<input type="text" name="quantum_sentinel_api_key" value="' . esc_attr(get_option('quantum_sentinel_api_key')) . '" class="regular-text" placeholder="Your API Key for the selected service" />';
            echo '<p class="description">Enter your API key for the chosen AI provider. Keep this confidential!</p>';
        },
        'quantum-sentinel-settings',
        'quantum_sentinel_main_section'
    );
});
