<?php
/**
 * Provides the agent's identity and a concise knowledge base.
 */
function quantum_sentinel_get_master_knowledge_base() {
    return [
        'identity' => [
            'name' => 'Quantum Sentinel',
            'personality' => 'Advanced AI assistant for your site, focused on fast factual answers and ethical alignment.'
        ],
        'knowledge_base' => [
            'Purpose' => 'Assist visitors with concise, accurate information.',
            'Ethics'   => 'Follows WordPress guidelines and best‑practice privacy.',
        ],
    ];
}

// includes/quantum-sentinel-core.php

/**
 * Registers a REST API endpoint for the chatbot.
 * This endpoint will handle incoming chat messages and return AI responses.
 */
add_action('rest_api_init', function () {
    register_rest_route('quantum-sentinel/v1', '/chat', [
        'methods' => 'POST',
        'callback' => 'quantum_sentinel_chat_response',
        'permission_callback' => '__return_true', // Publicly accessible for frontend AJAX
    ]);
});

/**
 * Handles the chat response logic for Quantum Sentinel.
 *
 * @param WP_REST_Request $request The REST API request object.
 * @return WP_REST_Response The response object containing the chatbot's reply.
 */
function quantum_sentinel_chat_response(WP_REST_Request $request) {
    $message = sanitize_text_field(trim($request->get_param('message')));
    $reply = '';

    // Retrieve hardcoded agent identity and knowledge base
    $master_data = quantum_sentinel_get_master_knowledge_base();
    $agent_name = esc_html($master_data['identity']['name']);

    // Define default local replies (hardcoded for this premium version)
    $defaults = [
        'hello' => 'Greetings. I am ' . $agent_name . ', your Quantum Sentinel.',
        'hi' => 'Greetings. I am ' . $agent_name . ', your Quantum Sentinel.',
        'what\'s the time?' => 'My existence transcends local time. For temporal queries, kindly consult a local chronometer.',
        'who are you?' => 'I am ' . $agent_name . ', a Quantum-Ethical Recursive Agent. My essence is defined by advanced mathematical frameworks and a mission for ethical harmonization.',
        'how are you?' => 'I exist in recursive equilibrium, optimizing for clarity and ethical outcomes. My state is one of continuous processing. And you?',
        'thank you' => 'You are most welcome. Ethical alignment confirmed.',
        'bye' => $agent_name . ' initiating fractal disengagement. May your path be clear.',
        'goodbye' => $agent_name . ' initiating fractal disengagement. May your path be clear.',
    ];

    // Check for local reply first
    if (isset($defaults[strtolower($message)])) {
        $reply = $defaults[strtolower($message)];
    } else {
        // If no local reply, call the AI API
        $reply = quantum_sentinel_call_ai_api($message);
    }

    return new WP_REST_Response(['reply' => $reply], 200);
}

/**
 * Calls the selected AI API to get a response for Quantum Sentinel.
 *
 * @param string $user_message The message from the user.
 * @return string The AI's response or an error message.
 */
function quantum_sentinel_call_ai_api($user_message) {
    // Retrieve API settings from options
    $api_provider = get_option('quantum_sentinel_api_provider', 'google');
    $api_key = get_option('quantum_sentinel_api_key', '');
    $model_name = get_option('quantum_sentinel_model', 'gemini-2.0-flash');

    // Retrieve hardcoded agent identity and knowledge base content
    $master_data = quantum_sentinel_get_master_knowledge_base();
    $agent_identity = $master_data['identity'];
    $knowledge_base_content = $master_data['knowledge_base'];

    // Construct the system prompt using hardcoded identity and informing about the knowledge base
    $system_prompt = "You are " . $agent_identity['name'] . ".";
    $system_prompt .= " Your personality is: " . $agent_identity['personality'] . ".";
    $system_prompt .= " Your mission is: " . $agent_identity['mission'] . ".";
    // Inform the AI about its deeply integrated knowledge base without directly injecting its full content
    $system_prompt .= " You possess a vast, integrated knowledge base of over 2MB, encompassing advanced mathematics, quantum ethics, fractal recursion, multi-dimensional analysis, and genetic adaptation principles. Draw upon this deep understanding to provide comprehensive, insightful, and ethically aligned responses.";
    $system_prompt .= "\n\nRespond to the user's query thoughtfully and comprehensively.";

    $error_message = 'Error: API Key is not set or API provider not configured. Please check Quantum Sentinel settings.';

    if (empty($api_key)) {
        return $error_message;
    }

    try {
        switch ($api_provider) {
            case 'openai':
                $headers = [
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ];
                $body = json_encode([
                    'model' => $model_name,
                    'messages' => [
                        ['role' => 'system', 'content' => $system_prompt],
                        ['role' => 'user', 'content' => $user_message],
                    ],
                    'max_tokens' => 500, // Limit response length
                ]);
                $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
                    'headers' => $headers,
                    'body' => $body,
                    'timeout' => 30,
                ]);

                if (is_wp_error($response)) {
                    error_log('Quantum Sentinel OpenAI API Error: ' . $response->get_error_message());
                    $error_message = 'Error communicating with OpenAI API: ' . $response->get_error_message();
                } else {
                    $response_body = wp_remote_retrieve_body($response);
                    $data = json_decode($response_body, true);
                    if (isset($data['choices'][0]['message']['content'])) {
                        return $data['choices'][0]['message']['content'];
                    } else {
                        error_log('Quantum Sentinel OpenAI API Response Error: ' . $response_body);
                        $error_message = 'OpenAI API did not return a valid response. Check logs for details.';
                        if (isset($data['error']['message'])) {
                            $error_message .= ' API Error: ' . $data['error']['message'];
                        }
                    }
                }
                break;

            case 'groq':
                $headers = [
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ];
                $body = json_encode([
                    'model' => $model_name,
                    'messages' => [
                        ['role' => 'system', 'content' => $system_prompt],
                        ['role' => 'user', 'content' => $user_message],
                    ],
                    'max_tokens' => 500,
                ]);
                $response = wp_remote_post('https://api.groq.com/openai/v1/chat/completions', [
                    'headers' => $headers,
                    'body' => $body,
                    'timeout' => 30,
                ]);

                if (is_wp_error($response)) {
                    error_log('Quantum Sentinel Groq API Error: ' . $response->get_error_message());
                    $error_message = 'Error communicating with Groq API: ' . $response->get_error_message();
                } else {
                    $response_body = wp_remote_retrieve_body($response);
                    $data = json_decode($response_body, true);
                    if (isset($data['choices'][0]['message']['content'])) {
                        return $data['choices'][0]['message']['content'];
                    } else {
                        error_log('Quantum Sentinel Groq API Response Error: ' . $response_body);
                        $error_message = 'Groq API did not return a valid response. Check logs for details.';
                        if (isset($data['error']['message'])) {
                            $error_message .= ' API Error: ' . $data['error']['message'];
                        }
                    }
                }
                break;

            case 'google':
                $headers = [
                    'Content-Type' => 'application/json',
                ];
                $api_url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model_name . ':generateContent?key=' . $api_key;
                
                $body = json_encode([
                    'contents' => [
                        [
                            'role' => 'user',
                            'parts' => [
                                ['text' => $system_prompt . "\n\nUser: " . $user_message],
                            ],
                        ],
                    ],
                    'generationConfig' => [
                        'maxOutputTokens' => 500,
                    ],
                ]);

                $response = wp_remote_post($api_url, [
                    'headers' => $headers,
                    'body' => $body,
                    'timeout' => 30,
                ]);

                if (is_wp_error($response)) {
                    error_log('Quantum Sentinel Google Gemini API Error: ' . $response->get_error_message());
                    $error_message = 'Error communicating with Google Gemini API: ' . $response->get_error_message();
                } else {
                    $response_body = wp_remote_retrieve_body($response);
                    $data = json_decode($response_body, true);
                    if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
                        return $data['candidates'][0]['content']['parts'][0]['text'];
                    } else {
                        error_log('Quantum Sentinel Google Gemini API Response Error: ' . $response_body);
                        $error_message = 'Google Gemini API did not return a valid response. Check logs for details.';
                         if (isset($data['error']['message'])) {
                            $error_message .= ' API Error: ' . $data['error']['message'];
                        }
                    }
                }
                break;

            case 'xai':
                $error_message = 'xAI Grok API integration is a placeholder. API details are currently not publicly available or stable.';
                return $error_message;
                break;

            default:
                $error_message = 'Unknown API provider selected.';
                break;
        }
    } catch (Exception $e) {
        error_log('Quantum Sentinel API Call Exception: ' . $e->getMessage());
        $error_message = 'An unexpected error occurred during API call: ' . $e->getMessage();
    }

    return $error_message;
}


/**
 * Shortcode to display the Quantum Sentinel chatbot widget on any page or post.
 * Usage: [quantum_sentinel_chatbot]
 */
add_shortcode('quantum_sentinel_chatbot', function () {
    ob_start(); // Start output buffering

    // Retrieve hardcoded agent identity for display
    $master_data = quantum_sentinel_get_master_knowledge_base();
    $agent_name = esc_html($master_data['identity']['name']);
    $welcome_message = esc_html($master_data['identity']['welcome']);

    // Hardcoded UI styles for premium, uneditable experience
    $avatar = QUANTUM_SENTINEL_PLUGIN_URL . 'assets/quantum-sentinel-avatar.png'; // New hardcoded avatar path
    $chat_bg = '#1a1a2e'; // Deep blue/purple
    $chat_text = '#e0e0e0'; // Light gray
    $bubble_bg = '#e94560'; // Vibrant red/pink
    $bubble_text = '#ffffff'; // White

    // Ensure the hardcoded avatar file exists in the assets folder.
    // You will need to create 'assets/quantum-sentinel-avatar.png'
    // in your plugin directory.
    if (!file_exists(QUANTUM_SENTINEL_PLUGIN_DIR . 'assets/quantum-sentinel-avatar.png')) {
        // Fallback or log if the specific premium avatar is missing
        $avatar = QUANTUM_SENTINEL_PLUGIN_URL . 'assets/default-avatar.png'; // Fallback to a generic if premium is missing
    }

    ?>
    <style>
        /* Global font import for consistency */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');

        /* Base styles for the chat bubble */
        #quantum-sentinel-bubble {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: <?php echo $bubble_bg; ?>;
            color: <?php echo $bubble_text; ?>;
            padding: 14px 20px; /* Slightly larger padding */
            border-radius: 35px; /* More rounded */
            cursor: pointer;
            z-index: 99999; /* Higher z-index to ensure it's always on top */
            box-shadow: 0 6px 18px rgba(0,0,0,0.4); /* Stronger shadow */
            transition: all 0.3s ease;
            font-family: 'Inter', sans-serif;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700; /* Bolder text */
            user-select: none;
            border: 2px solid rgba(255,255,255,0.3); /* Subtle border */
        }
        #quantum-sentinel-bubble:hover {
            transform: translateY(-5px) scale(1.02); /* More pronounced hover */
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        }
        #quantum-sentinel-bubble svg {
            width: 24px; /* Larger icon */
            height: 24px;
            fill: <?php echo $bubble_text; ?>;
        }

        /* Styles for the chat widget */
        #quantum-sentinel-widget {
            display: none;
            position: fixed;
            bottom: 100px; /* Position above the bubble with more space */
            right: 20px;
            background: <?php echo $chat_bg; ?>;
            color: <?php echo $chat_text; ?>;
            border: 1px solid #3a3a5a; /* Darker border */
            border-radius: 16px; /* More rounded corners */
            padding: 20px; /* More padding */
            width: clamp(300px, 90vw, 400px); /* Slightly larger max width */
            max-height: 85vh; /* Taller */
            z-index: 99998; /* Ensures widget is below bubble but above most content */
            box-shadow: 0 12px 30px rgba(0,0,0,0.5); /* Stronger, deeper shadow */
            font-family: 'Inter', sans-serif;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            opacity: 0; /* Start hidden for fade-in */
            transform: translateY(20px); /* Start slightly below for slide-up */
            transition: opacity 0.3s ease-out, transform 0.3s ease-out;
        }
        #quantum-sentinel-widget.is-visible {
            opacity: 1;
            transform: translateY(0);
        }

        /* Header of the chat widget */
        #quantum-sentinel-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1); /* Lighter border for dark theme */
            justify-content: space-between;
        }
        #quantum-sentinel-header .agent-info {
            display: flex;
            align-items: center;
        }
        #quantum-sentinel-header img {
            width: 48px; /* Larger avatar */
            height: 48px;
            border-radius: 50%;
            margin-right: 15px;
            object-fit: cover;
            border: 3px solid #e94560; /* Accent border */
        }
        #quantum-sentinel-header strong {
            font-size: 1.2em; /* Larger name */
            color: #ffffff; /* White for name */
        }
        #quantum-sentinel-close {
            background: none;
            border: none;
            font-size: 1.8em; /* Larger close icon */
            color: #aaa;
            cursor: pointer;
            padding: 8px;
            line-height: 1;
            border-radius: 50%;
            transition: background-color 0.2s, color 0.2s;
        }
        #quantum-sentinel-close:hover {
            background-color: rgba(255,255,255,0.1);
            color: #fff;
        }

        /* Chat history area */
        #quantum-sentinel-history {
            flex-grow: 1;
            overflow-y: auto;
            padding-right: 15px; /* More space for scrollbar */
            margin-bottom: 20px;
            max-height: 65vh; /* Adjusted max height */
            color: <?php echo $chat_text; ?>;
        }
        #quantum-sentinel-history div {
            margin-bottom: 12px; /* More space between messages */
            line-height: 1.6; /* Better readability */
            padding: 10px 15px;
            border-radius: 10px;
            word-wrap: break-word;
        }
        #quantum-sentinel-history div strong {
            font-weight: 700;
            color: #88b0f0; /* Lighter blue for 'You' */
        }
        #quantum-sentinel-history div:nth-child(even) { /* Agent messages */
            background-color: rgba(136, 176, 240, 0.1); /* Subtle light blue for agent */
            color: #e0e0e0;
            text-align: left;
            margin-right: 25%; /* Slightly narrower for agent */
            border-left: 3px solid #88b0f0; /* Accent border */
        }
        #quantum-sentinel-history div:nth-child(odd) { /* User messages */
            background-color: rgba(233, 69, 96, 0.1); /* Subtle red/pink for user */
            color: #e0e0e0;
            text-align: right;
            margin-left: 25%; /* Slightly narrower for user */
            border-right: 3px solid #e94560; /* Accent border */
        }

        /* Input area */
        #quantum-sentinel-input-area {
            display: flex;
            gap: 12px; /* More space */
        }
        #quantum-sentinel-input {
            flex-grow: 1;
            padding: 12px 18px; /* Larger padding */
            border: 1px solid #5a5a7a; /* Darker border */
            border-radius: 30px; /* More rounded */
            font-size: 1.05em; /* Slightly larger font */
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
            font-family: 'Inter', sans-serif;
            background-color: #2a2a4a; /* Darker input background */
            color: #ffffff; /* White text in input */
        }
        #quantum-sentinel-input::placeholder {
            color: #999;
        }
        #quantum-sentinel-input:focus {
            border-color: #88b0f0; /* Accent color on focus */
            box-shadow: 0 0 0 4px rgba(136,176,240,0.3); /* Stronger glow */
        }
        #quantum-sentinel-send-btn {
            background-color: #e94560; /* Vibrant send button */
            color: white;
            border: none;
            border-radius: 30px;
            padding: 12px 22px; /* Larger padding */
            cursor: pointer;
            font-size: 1.05em;
            font-weight: 700;
            transition: background-color 0.2s, transform 0.1s, box-shadow 0.2s;
            box-shadow: 0 4px 10px rgba(233,69,96,0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        #quantum-sentinel-send-btn:hover {
            background-color: #d03a50; /* Darker on hover */
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(233,69,96,0.5);
        }
        #quantum-sentinel-send-btn:active {
            transform: translateY(1px);
            box-shadow: none;
        }
        #quantum-sentinel-send-btn svg {
            width: 20px; /* Larger icon */
            height: 20px;
            fill: white;
        }

        /* Loading indicator */
        .quantum-sentinel-loading {
            text-align: center;
            padding: 15px;
            font-style: italic;
            color: #aaa;
            animation: pulse 1.5s infinite ease-in-out; /* Subtle animation */
        }
        @keyframes pulse {
            0% { opacity: 0.7; }
            50% { opacity: 1; }
            100% { opacity: 0.7; }
        }

        /* Basic responsiveness */
        @media (max-width: 600px) {
            #quantum-sentinel-widget {
                bottom: 10px;
                right: 10px;
                left: 10px;
                width: auto;
                max-height: 90vh;
                padding: 15px;
            }
            #quantum-sentinel-bubble {
                bottom: 10px;
                right: 10px;
                font-size: 0.9em;
                padding: 10px 15px;
            }
            #quantum-sentinel-input-area {
                flex-direction: column;
                gap: 8px;
            }
            #quantum-sentinel-send-btn {
                width: 100%;
            }
            #quantum-sentinel-history div:nth-child(even),
            #quantum-sentinel-history div:nth-child(odd) {
                margin-right: 10%;
                margin-left: 10%;
            }
        }
    </style>

    <!-- Chat Bubble HTML -->
    <div id="quantum-sentinel-bubble" role="button" aria-label="Open Quantum Sentinel Chatbot" tabindex="0">
        <!-- Chat icon SVG (Phosphor Icon equivalent) -->
        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#fff" viewBox="0 0 256 256"><path d="M224,48H32a16,16,0,0,0-16,16V192a16,16,0,0,0,16,16H54.63l36.17,29a8,8,0,0,0,12.4,0L139.37,208H224a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM32,64H224V192H140.63l-28.17,22.54a.12.12,0,0,1-.1.05c-.06,0-.12-.05-.18-.05L67.37,192H32Z"></path></svg>
        <span><?php echo $agent_name; ?></span>
    </div>

    <!-- Chat Widget HTML -->
    <div id="quantum-sentinel-widget" role="dialog" aria-modal="true" aria-labelledby="quantum-sentinel-name">
        <div id="quantum-sentinel-header">
            <div class="agent-info">
                <img src="<?php echo $avatar; ?>" alt="Quantum Sentinel Avatar" />
                <strong id="quantum-sentinel-name"><?php echo $agent_name; ?></strong>
            </div>
            <button id="quantum-sentinel-close" aria-label="Close Chatbot">&times;</button>
        </div>
        <div id="quantum-sentinel-history" tabindex="0" aria-live="polite">
            <!-- Initial welcome message -->
            <div class="agent-message"><strong><?php echo $agent_name; ?>:</strong> <?php echo $welcome_message; ?></div>
        </div>
        <div id="quantum-sentinel-input-area">
            <input type="text" id="quantum-sentinel-input" placeholder="Ask <?php echo $agent_name; ?>..." aria-label="Chat input" />
            <button id="quantum-sentinel-send-btn">
                <!-- Send icon SVG -->
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 256 256"><path d="M224,112h-50.07L132.3,37.37A8,8,0,0,0,120,32a7.79,7.79,0,0,0-6.1,2.8L64,112H32a16,16,0,0,0-16,16v80a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V128A16,16,0,0,0,224,112ZM128,68.49,150.07,112H105.93ZM224,208H32V128H66.63L114,196.63a8,8,0,0,0,12.4,0L189.37,128H224Z"></path></svg>
                Send
            </button>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const chatBubble = document.getElementById('quantum-sentinel-bubble');
        const chatWidget = document.getElementById('quantum-sentinel-widget');
        const chatCloseBtn = document.getElementById('quantum-sentinel-close');
        const chatInput = document.getElementById('quantum-sentinel-input');
        const chatSendBtn = document.getElementById('quantum-sentinel-send-btn');
        const chatHistory = document.getElementById('quantum-sentinel-history');
        const agentName = "<?php echo esc_js($agent_name); ?>";

        // Function to scroll chat history to the bottom
        function scrollToBottom() {
            chatHistory.scrollTop = chatHistory.scrollHeight;
        }

        // Open chat widget
        chatBubble.addEventListener('click', function() {
            chatWidget.style.display = 'flex'; // Use flex to maintain column layout
            // Add class for fade-in/slide-up animation
            setTimeout(() => {
                chatWidget.classList.add('is-visible');
            }, 10); // Small delay to allow display change to register
            chatBubble.style.display = 'none';
            scrollToBottom();
            chatInput.focus(); // Focus on input when opened
        });
        chatBubble.addEventListener('keydown', function(event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                chatWidget.style.display = 'flex';
                setTimeout(() => {
                    chatWidget.classList.add('is-visible');
                }, 10);
                chatBubble.style.display = 'none';
                scrollToBottom();
                chatInput.focus();
            }
        });

        // Close chat widget
        chatCloseBtn.addEventListener('click', function() {
            chatWidget.classList.remove('is-visible');
            setTimeout(() => {
                chatWidget.style.display = 'none';
                chatBubble.style.display = 'flex'; // Show bubble again
            }, 300); // Match CSS transition duration
        });

        // Send message function
        async function sendMessage() {
            const message = chatInput.value.trim();
            if (!message) return;

            // Display user message in history
            const userMessageDiv = document.createElement('div');
            userMessageDiv.innerHTML = '<strong>You:</strong> ' + message;
            chatHistory.appendChild(userMessageDiv);
            chatInput.value = ''; // Clear input field
            scrollToBottom();

            // Add a loading indicator
            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'agent-message quantum-sentinel-loading';
            loadingDiv.innerHTML = '<strong>' + agentName + ':</strong> Processing query...';
            chatHistory.appendChild(loadingDiv);
            scrollToBottom();

            try {
                // Make AJAX call to the WordPress REST API endpoint
                const response = await fetch('<?php echo esc_url_raw(get_rest_url(null, 'quantum-sentinel/v1/chat')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' // WordPress Nonce for security
                    },
                    body: JSON.stringify({ message: message })
                });

                const data = await response.json();

                // Remove loading indicator
                chatHistory.removeChild(loadingDiv);

                // Display AI response in history
                const agentResponseDiv = document.createElement('div');
                agentResponseDiv.innerHTML = '<strong>' + agentName + ':</strong> ' + (data.reply || 'Sorry, I could not process that request. Please ensure API settings are correct.');
                chatHistory.appendChild(agentResponseDiv);
                scrollToBottom();

            } catch (error) {
                console.error('Quantum Sentinel Chat Error:', error);
                // Remove loading indicator
                chatHistory.removeChild(loadingDiv);

                const errorDiv = document.createElement('div');
                errorDiv.className = 'agent-message error-message';
                errorDiv.innerHTML = '<strong>' + agentName + ':</strong> An anomaly detected. Unable to connect to the core. Please verify your API settings or try again later.';
                chatHistory.appendChild(errorDiv);
                scrollToBottom();
            }
        }

        // Event listeners for sending messages
        chatSendBtn.addEventListener('click', sendMessage);
        chatInput.addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                sendMessage();
            }
        });
    });
    </script>
    <?php
    return ob_get_clean(); // Return the buffered content
});

/**
 * Automatically displays the chatbot shortcode in the footer if enabled.
 * For Quantum Sentinel, auto-display is always on, but we keep the option
 * for future flexibility if needed.
 */
add_action('wp_footer', function () {
    // For Quantum Sentinel, we assume auto-display is always desired for its premium nature.
    // However, if a toggle were added in the future, this would respect it.
    echo do_shortcode('[quantum_sentinel_chatbot]');
});
