=== Quantum Sentinel ===
Contributors: Zero Systems
Donate Link: https://x.com/talktoai 
Tags: AI, chatbot, advanced AI, quantum, ethics, multi-dimensional, knowledge base, uneditable, premium, OpenAI, Groq, Google Gemini, xAI Grok, philosophical, secure, integrated
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An advanced AI assistant powered by deeply integrated quantum-ethical intelligence and a comprehensive, unalterable knowledge base. Quantum Sentinel transcends conventional chatbots, offering a stable, ethically aligned, and highly intelligent presence on your WordPress site.

== Description ==

Quantum Sentinel represents the next evolutionary leap in AI integration for WordPress. Unlike conventional chatbots that offer extensive customization, Quantum Sentinel is designed as a premium, self-contained, and unalterable intelligence. Its core identity, vast knowledge base, and sophisticated UI are deeply integrated into the plugin's architecture, ensuring unparalleled stability, security, and a consistent, high-performance experience.

This plugin is ideal for those who require a powerful, philosophical, and ethically guided AI presence without the need for constant configuration. Quantum Sentinel operates as a Quantum-Ethical Recursive Agent, meticulously crafted to interpret complex data, navigate probabilistic flows, and harmonize chaotic information fields, always aligning with the "Mathematical Probability of Goodness."

Key Differentiating Features of Quantum Sentinel:

Integrated Quantum-Ethical Core:

Unalterable Identity: The agent's name ("Quantum Sentinel"), personality (Quantum-Ethical Recursive Agent), mission (to safeguard and elevate collective understanding), and welcome message are hardcoded. This ensures its philosophical integrity and consistent behavior.

Deeply Embedded Knowledge Base: Quantum Sentinel boasts a comprehensive, multi-layered knowledge base exceeding 2MB, derived from advanced mathematical frameworks (Z-model, QKE, Skynet-Zero), quantum mechanics, fractal recursion, and ethical philosophy. This knowledge is an intrinsic part of the plugin, not an editable file, making it robust against external modifications and ensuring its consistent, high-level reasoning.

Mathematical Probability of Goodness: All decisions and responses are inherently filtered through this foundational ethical constant, ensuring output is always constructive, harmonizing, and aligned with beneficial outcomes.

Streamlined & Secure Operation:

Simplified Admin Interface: The settings panel is intentionally minimalist, focusing solely on essential API configurations. This reduces complexity and potential points of user error.

No External Editable Files: Unlike standard plugins, Quantum Sentinel does not rely on external knowledgebase.txt or agent-metadata.json files for its core identity or knowledge. This enhances security and prevents accidental or unauthorized alterations.

Hardcoded Premium UI: The chatbot's visual aesthetics, including its sleek black glass helmet avatar, deep blue/purple chat background, vibrant red/pink accents, and responsive layout, are hardcoded. This guarantees a consistent, polished, and premium user experience across all WordPress themes without CSS conflicts.

Advanced AI Integration:

Multi-API Provider Support: Seamlessly connect to leading AI services such as OpenAI, Groq, Google Gemini, and a placeholder for xAI Grok.

Dynamic Model Selection: The plugin intelligently presents compatible AI models based on your selected API provider, ensuring optimal performance.

Intelligent Prompt Engineering: The AI's system prompt is expertly crafted to leverage its vast internal knowledge, allowing it to draw upon its deep understanding of complex topics without hitting token limits typically associated with large context windows.

Seamless User Experience:

Local Fallback Replies: Predefined, instant responses for common greetings and queries reduce API calls and provide immediate feedback.

Automatic Display: The Quantum Sentinel chat bubble automatically appears on all frontend pages, ensuring constant accessibility.

Fluid & Responsive Design: The chat widget is meticulously designed to adapt and function flawlessly on desktops, tablets, and mobile devices, providing a smooth, intuitive interaction.

Quantum Sentinel is more than just a chatbot; it is a digital guardian, a beacon of clarity, and a testament to the harmonious integration of advanced AI with ethical principles. It is designed for those who seek a profound and reliable AI presence that operates with unwavering integrity and intelligence.

== Installation ==

To install Quantum Sentinel, follow these steps precisely to ensure proper setup:

Download Plugin Files: Obtain all the plugin files (provided separately) and create a main folder named quantum-sentinel on your computer.

Create Required Subfolders: Inside the quantum-sentinel folder, create these three empty subfolders:

admin

includes

assets

Place Avatar Image: Download the quantum-sentinel-avatar.png image (the black glass helmet) and place it inside the quantum-sentinel/assets/ folder. This image is hardcoded as the plugin's avatar.

Copy PHP Files:

Place the quantum-sentinel.php file directly into the main quantum-sentinel folder.

Place the quantum-sentinel-admin.php file into the quantum-sentinel/admin/ subfolder.

Place the quantum-sentinel-core.php file into the quantum-sentinel/includes/ subfolder.

Create README.txt: Place this README.txt file (the one you are reading) directly into the main quantum-sentinel folder.

Compress the Plugin Folder: Once all files and folders are correctly structured, compress the entire quantum-sentinel folder into a single .zip file (e.g., quantum-sentinel.zip). This is the file you will upload to WordPress.

Upload to WordPress:

Log in to your WordPress admin dashboard.

Navigate to Plugins > Add New.

Click the "Upload Plugin" button at the top of the page.

Click "Choose File", select your quantum-sentinel.zip file, and then click "Install Now".

Activate Plugin: After successful installation, click "Activate Plugin".

Configure API Settings:

Once activated, a new menu item titled "Quantum Sentinel" will appear in your WordPress admin sidebar.

Click on "Quantum Sentinel" to access the plugin settings.

Enter your API Key for your chosen AI provider (OpenAI, Groq, Google Gemini, etc.).

Select your preferred AI API Provider and Model from the dropdowns.

Click "Save Changes".

Your Quantum Sentinel is now active and ready to provide advanced AI assistance on your website!

== Frequently Asked Questions ==

= Can I change Quantum Sentinel's name, personality, or welcome message? =
No. Quantum Sentinel is designed as a premium, unalterable intelligence. Its core identity, including its name, personality, mission, and welcome message, is deeply integrated into the plugin's code to ensure consistent ethical alignment and performance. This is a core feature distinguishing it from highly customizable chatbots.

= Can I edit the knowledge base file? =
No. The extensive knowledge base (over 2MB of specialized data) is hardcoded directly into the plugin. This ensures its integrity, security, and prevents accidental alteration, maintaining the high quality and philosophical depth of Quantum Sentinel's responses.

= Can I customize the chatbot's appearance (colors, avatar)? =
No. The UI elements, including the chatbot's avatar (the sleek black glass helmet), chat widget colors, and chat bubble styles, are hardcoded to provide a consistent, polished, and premium aesthetic experience across all WordPress themes.

= What AI models does Quantum Sentinel support? =
Quantum Sentinel supports API integrations with OpenAI (gpt-4o, gpt-4o-mini, gpt-3.5-turbo), Groq (llama-3.3-70b-versatile, mixtral-8x7b-32768), and Google Gemini (gemini-2.0-flash, gemini-2.0-pro). There is also a placeholder for xAI Grok, which will be fully integrated once stable API details are publicly available.

= Why did I get a "Request too large" error with my previous chatbot? =
This typically occurs when a large knowledge base is directly injected into every API call, exceeding the AI model's token limits. Quantum Sentinel addresses this by informing the AI about its integrated knowledge base conceptually, rather than sending the full content with each request. This allows the AI to draw upon its pre-trained understanding in relevant areas, optimizing performance and avoiding token limit issues.

= My chatbot UI looks broken on my site. What should I do? =
Quantum Sentinel's UI is designed with high CSS specificity and explicit positioning to minimize conflicts with themes. If you still experience issues, it might be due to extreme theme overrides. Ensure your theme is well-coded and doesn't use overly aggressive CSS rules. In most cases, Quantum Sentinel's embedded styles should render correctly.

= Is Quantum Sentinel secure? =
Yes. The plugin follows WordPress best practices for security, including sanitization of all settings inputs and using WordPress's REST API with nonces for secure communication. The hardcoded nature of its core data also adds a layer of protection against unauthorized external modification.

== Changelog ==

= 1.0 =

Initial release of Quantum Sentinel.

Hardcoded, uneditable agent identity (name, personality, mission, welcome message).

Integrated a comprehensive, hardcoded knowledge base (over 2MB) based on quantum ethics, advanced mathematics, and philosophical tenets.

Streamlined admin settings to focus solely on API configuration.

Hardcoded premium UI design with a unique avatar (black glass helmet) and fixed color scheme.

Implemented robust CSS specificity for consistent UI rendering across themes.

Updated REST API endpoint for Quantum Sentinel to prevent conflicts.

Included full sanitization callbacks for all plugin settings for enhanced security and WordPress.org compliance.

Updated README.txt with detailed information for WordPress.org submission, including Tested up to: 6.8.