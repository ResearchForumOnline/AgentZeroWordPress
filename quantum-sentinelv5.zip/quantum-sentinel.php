<?php
/*
Plugin Name: Quantum Sentinel
Description: Advanced AI assistant for WordPress powered by Quantum Sentinel.
Version: 1.0.2
Requires PHP: 7.4
Author: Zero Systems
License: GPLv2 or later
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define core path/url constants if they aren't already.
if ( ! defined( 'QUANTUM_SENTINEL_PLUGIN_URL' ) ) {
    define( 'QUANTUM_SENTINEL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'QUANTUM_SENTINEL_PLUGIN_DIR' ) ) {
    define( 'QUANTUM_SENTINEL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

// Include core functionality and admin interface.
require_once QUANTUM_SENTINEL_PLUGIN_DIR . 'includes/quantum-sentinel-core.php';
require_once QUANTUM_SENTINEL_PLUGIN_DIR . 'admin/quantum-sentinel-admin.php';

